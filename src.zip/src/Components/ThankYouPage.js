import React from 'react';
import Navbar from './Navbar';
import Footer from './Footer';

export default function ThankYouPage() {
  return (
    <>
      <Navbar />
      <div className="container-fluid d-flex flex-column justify-content-center vh-100">
        <div className="text-center">
          <img src="/ThankYouIcon.svg" alt="Bellhopt Logo" className="mb-3" style={{ width: '150px' }} />
          <h1 className="fw-bold text-danger">Thank you!</h1>
          <p className="text-muted">Confirmation number: <strong>GYK209021</strong></p>
          <p className="text-muted fw-bold" style={{ maxWidth: '800px', margin: '0 auto' }}>
            Grocery superheroes to the rescue! Bellhopt is donning their capes and saving the day by delivering your grocery order to your rental. Stay tuned for a heroic email confirmation!
          </p>
        </div>
      </div>
      <Footer />
    </>
  );
}
