import React from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import { useMediaQuery } from 'react-responsive';
import { useNavigate } from 'react-router-dom';

const MyCart = () => {
  const isMobile = useMediaQuery({ query: '(max-width: 576px)' });
  const navigate=useNavigate();
  const handleClick = () => {
    navigate('/checkout'); 
  };
  return (
    <>
      {/* Navbar Section*/}
      <Navbar />

      {/* My Cart Section */}
      <div className="container my-5 mb-5">
        <div className="row">
          {/* Cart Items Section */}
          <div className="col-lg-8 mb-4">
            <h4 className="mb-4"><b>My Cart</b></h4>

            {/* Table Header */}
            <div className="d-flex justify-content-between border-bottom pb-2">
              <div className="col text-center text-secondary fw-bold">Product</div>
              <div className="col text-center text-secondary fw-bold">Price</div>
              <div className="col text-center text-secondary fw-bold">Quantity</div>
              {!isMobile && (
                <div className="col text-center text-secondary fw-bold">Order Summary</div>
              )}
            </div>

            {/* Repeated Cart Items */}
            {[...Array(4)].map((_, index) => (
              <div key={index} className="d-flex justify-content-between align-items-center border-bottom py-3">
                <div className="d-flex align-items-center col">
                  {/* Product Image with Gray Border */}
                  <img src="OrangeCart.png" alt="orange" className="img-fluid" style={{ width: '50px', border: '1px solid gray' }} />

                  {/* Product Details */}
                  <div className="ms-3">
                    <p className="fw-bold mb-1">Orange</p>
                    <p className="text-muted mb-0">VIP Orange/Dz</p>
                  </div>
                </div>

                {/* Price */}
                <div className="col text-center">
                  <p className="mb-0"><b>$8.50</b></p>
                </div>

                {/* Quantity and Edit */}
                <div className="d-flex align-items-center col justify-content-center">
                  <button className="btn btn-danger rounded-circle d-flex justify-content-center align-items-center" style={{ width: '40px', height: '40px' }}>-</button>
                  <span className="mx-2">1</span>
                  <button className="btn btn-danger rounded-circle d-flex justify-content-center align-items-center" style={{ width: '40px', height: '40px' }}>+</button>
                </div>

                {/* Delete and Edit Buttons (Desktop) or Total (Mobile) */}
                {!isMobile ? (
                  <div className="col text-center">
                    <button className="btn btn-sm">
                      <img src="Edit.svg" alt="Edit Icon" />
                    </button>
                    <button className="btn btn-sm">
                      <img src="Delete.svg" alt="Delete Icon" />
                    </button>
                  </div>
                ) : (
                  <div className="col text-center">
                    <p className='text-black'><b>Total</b></p>
                    <p className="mb-0 text-secondary"><b>$8.50</b></p>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Order Summary Section */}
          <div className="col-lg-4">
            <div className="p-3 rounded" style={{ border: '1px solid gray' }}>
              <h4 className='text-center text-secondary'>Order Summary</h4>
              <div className="d-flex justify-content-between">
                <p>Subtotal:</p>
                <p>$34.50</p>
              </div>
              <div className="d-flex justify-content-between">
                <p>Tax:</p>
                <p>$1.72</p>
              </div>
              <div className="d-flex justify-content-between">
                <p>Delivery:</p>
                <p>$14.99</p>
              </div>
              <hr />
              <div className="d-flex justify-content-between fw-bold">
                <p>Total:</p>
                <p>$51.21</p>
              </div>
              <div className='d-flex justify-content-center'>
                <button className="btn btn-danger mt-3 rounded-pill" onClick={handleClick}>Proceed to Checkout</button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer Section */}
      <Footer />
    </>
  );
};

export default MyCart;
