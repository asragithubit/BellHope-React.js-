import React from 'react'
import Navbar from './Components/Navbar'
import Header from './Components/Header'
import FruitsandVegetables from './Components/Fruits and Vegetables'
import Footer from './Components/Footer'
import Packages from './Components/Packages'

export default function HomePage() {
  const packageItems = [
    {
      imgSrc: "SpriteFanta.png",
      altText: "Coke, Sprite, Fanta",
      price: "$9.65",
      originalPrice: "$11.25",
      description: "Coca-Cola, Sprite, Fanta (12-pack Variety)",
    },
    {
      imgSrc: "TomatoLime.png",
      altText: "Whiskey Package",
      price: "$129.65",
      originalPrice: "$131.25",
      description: "Lorem ipsum dollar sign is the placeholder text.",
    },
    {
      imgSrc: "Dove.png",
      altText: "Dove Package",
      price: "$9.65",
      originalPrice: "$11.25",
      description: "Tomato, Carrot, Green Lime, Onion, Potato, Red Chili",
    }
  ];
  return (
    <div>
      <Navbar />
      <Header imgLink="/headerIcon.svg" /> 
      <FruitsandVegetables title='Fruits and Vegetables'/>
      <Packages items={packageItems}/>
      <Footer />
    </div>
  );
}