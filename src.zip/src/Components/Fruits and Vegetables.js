import React from 'react'
import { useMediaQuery } from 'react-responsive';
import { useNavigate } from 'react-router-dom';
export default function FruitsandVegetables(props) {
    const isMobile = useMediaQuery({ query: '(max-width: 576px)' });
    const navigate=useNavigate();

    const handleClick = () => {
        navigate('/products'); 
      };
  return (
    <div className="container mt-3 my-5">
        <div className="d-flex justify-content-between align-items-center mb-3">
            <h2><b>{props.title}</b></h2>
            <div>
                <button className="btn btn-sm mx-1" style={isMobile ? { display: 'none' } : {}}>
                    <img src="/LeftArrow.png" alt="Left Arrow Button" />
                </button>
                <button className="btn btn-sm" style={isMobile ? { display: 'none' } : {}}>
                    <img src="/RightArrow.png" alt="Right Arrow Button" />
                </button>
                <a href="/" className="text-danger" onClick={(e) => {
        	    e.preventDefault();
                handleClick();
                }}>See all</a>
            </div>
        </div>
        <div className="row row-cols-2 row-cols-lg-4 g-4 px-2">
            <div className="col">
                <div className="card border-0 h-100">
                    <img src="Strawberry.png" className="card-img-top" alt="Strawberry" />
                </div>
            </div>
            <div className="col">
                <div className="card border-0 h-100">
                    <img src="Apple Green.png" className="card-img-top" alt="Green Apple" />
                </div>
            </div>

            <div className="col">
                <div className="card border-0 h-100">
                    <img src="Orange.png" className="card-img-top" alt="Orange" />
                </div>
            </div>

            <div className="col">
                <div className="card border-0 h-100">
                    <img src="Green Lemon.png" className="card-img-top" alt="Green Lemon" />
                </div>
            </div>
        </div>
        <div className="row row-cols-2 row-cols-lg-4 g-4 px-2">
            <div className="col">
                <div className="card border-0 h-100">
                    <img src="Red Onion.png" className="card-img-top" alt="Red Onion" />
                </div>
            </div>
            <div className="col">
                <div className="card border-0 h-100">
                    <img src="Tomato.png" className="card-img-top" alt="Tomato" />
                </div>
            </div>

            <div className="col">
                <div className="card border-0 h-100">
                    <img src="Pomegrante.png" className="card-img-top" alt="Pomegrante" />
                </div>
            </div>

            <div className="col">
                <div className="card border-0 h-100">
                    <img src="Potato.png" className="card-img-top" alt="Potato" />
                </div>
            </div>
        </div>
    </div>
  )
}
