import React, { useState, useEffect } from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import { useMediaQuery } from 'react-responsive';
import { useNavigate } from 'react-router-dom';
const Checkout = () => {
  const isMobile = useMediaQuery({ query: '(max-width: 576px)' });
  const navigate=useNavigate();
  const handleClick = () => {
    navigate('/thankYou'); 
  };

  // State for form fields
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [addressConfirmed, setAddressConfirmed] = useState(false);
  const [isButtonDisabled, setIsButtonDisabled] = useState(true);

  useEffect(() => {
    if (date && time && phoneNumber && addressConfirmed) {
      setIsButtonDisabled(false); 
    } else {
      setIsButtonDisabled(true); 
    }
  }, [date, time, phoneNumber, addressConfirmed]);

  return (
    <>
      {/* Navbar Section */}
      <Navbar />

      {/* Checkout Section */}
      <div className="container my-5">
        <div className="row">
          <div className={isMobile ? "col-12 mb-4" : "col-lg-8 mb-4"}>
            <div className="card p-4">
              
              <div className="card border-1 mb-4">
                <div className="card-body">
                  <h5><b>Expected Time of Arrival</b></h5>
                  <hr className='text-gray'/>
                  <div className="row">
                    <div className="col-6">
                      <p><b>Date</b></p>
                      <input 
                        type="date" 
                        className="form-control bg-light py-3" 
                        placeholder="MM/DD/YYYY" 
                        value={date} 
                        onChange={(e) => setDate(e.target.value)}
                      />
                    </div>
                    <div className="col-6">
                      <p><b>Time</b></p>
                      <input 
                        type="time" 
                        className="form-control py-3 bg-light" 
                        value={time} 
                        onChange={(e) => setTime(e.target.value)} // Update time state
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Contact Information */}
              <div className="card border-1 mb-4">
                <div className="card-body">
                  <h5><b>Contact Information</b></h5>
                  <p className='text-secondary'>Phone Number</p>
                  <input 
                    type="text" 
                    className="form-control py-3" 
                    placeholder="+123 456-7890" 
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)} // Update phone number state
                  />
                </div>
              </div>

              {/* Delivery Address */}
              <div className="card border-1 mb-4">
                <div className="card-body">
                  <h5><b>Delivery Address</b> <span className='text-secondary'>(auto fetched)</span></h5>
                  <div className="input-group mb-3">
                    <span className="input-group-text bg-white border-0">
                      <img 
                        src="Location.svg" 
                        alt="Location Icon" 
                        style={{ width: '30px', height: '30px' }} 
                      />
                    </span>
                    <input 
                      type="text" 
                      className="form-control py-3 border-0" 
                      value="LH 123, Apt. 2, Zabar's, Broadway, NY, USA" 
                      readOnly
                    />
                  </div>
                  <div className="form-check mt-2">
                    <input 
                      className="form-check-input bg-danger" 
                      type="checkbox" 
                      checked={addressConfirmed}
                      onChange={() => setAddressConfirmed(!addressConfirmed)}
                    />
                    <label className="form-check-label">
                      I've confirmed the above address
                    </label>
                  </div>
                </div>
              </div>

              {/* Split Total Bill */}
              <div className="card border-1 mb-4">
                <div className="card-body">
                  <h5>Split Total Bill <span className='text-secondary'>(Optional)</span></h5>
                  <hr className='text-secondary'/>
                  <p className='text-secondary text-center fs-4'>No additional email added yet</p>
                </div>
              </div>

            </div>          
          </div>

          {/* Right Section - Order Summary */}
          <div className={isMobile ? "col-12" : "col-lg-4"}>
            <div className="card p-4">
              <h5 className="text-center text-secondary">Order Summary</h5>
              <div className="d-flex justify-content-between">
                <p className='text-black fw-bold'>Subtotal:</p>
                <p className='fw-bold'>$34.50</p>
              </div>
              <div className="d-flex justify-content-between">
                <p className='text-black fw-bold'>Platform Fee (5%):</p>
                <p className='fw-bold'>$1.72</p>
              </div>
              <div className="d-flex justify-content-between">
                <p className='text-black fw-bold'>Driver's Fee:</p>
                <p className='fw-bold'>$14.99</p>
              </div>

              {/* Tip for Driver */}
              <h6 className="my-4">Tip for Driver</h6>
              <div className="btn-group d-flex bg-light rounded-pill" role="group">
                <button className="btn rounded-pill">10%</button>
                <button className="btn rounded-pill">15%</button>
                <button className="btn btn-outline-danger active rounded-pill">20%</button>
                <button className="btn rounded-pill">Custom</button>
              </div>

              <hr className='text-gray' />
              <div className="d-flex justify-content-between fw-bold">
                <p>Total:</p>
                <p>$61.45</p>
              </div>
              <hr className='text-gray' />
              <p>Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our <a href=''><b className='text-dark'>privacy policy</b></a></p>
              <div className='d-flex justify-content-center'>
                <button 
                  className="btn btn-danger mt-3 w-75 rounded-pill py-2" 
                  disabled={isButtonDisabled}
                  onClick={handleClick}
                >
                  Place Order
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer Section */}
      <Footer />
    </>
  );
};

export default Checkout;
