import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useMediaQuery } from 'react-responsive';
import 'bootstrap-icons/font/bootstrap-icons.css';

export default function Navbar() {
  const isMobile = useMediaQuery({ query: '(max-width: 576px)' });
  const isTablet = useMediaQuery({ query: '(min-width: 576px) and (max-width: 768px)' });

  const navigate = useNavigate(); // Hook for navigation

  // Function to handle cart icon click
  const handleCartClick = () => {
    navigate('/myCart'); 
  };

  return (
    <div className="container-fluid bg-white py-3 d-flex align-items-center">
      <img src="/logo.png" alt="Logo" className="img-fluid mx-md-5 mx-1" style={{ width: '70px', height: '50px' }} />

      {/* Render search bar only if not mobile */}
      {!isMobile && (
        <form className={`d-flex mx-auto ${isTablet ? 'ps-3' : 'ps-5'}`} role="search">
          <div className={`input-group bg-light rounded-pill py-2`} style={isTablet ? { width: '250px', marginLeft: '100px' } : { width: '500px', marginLeft: '500px' }}>
            <span className="input-group-text bg-light border-0 rounded-pill">
              <i className="bi bi-search"></i>
            </span>
            <input
              type="search"
              className="form-control bg-light border-0 rounded-pill"
              placeholder="Search products here..."
              aria-label="Search"
            />
          </div>
        </form>
      )}

      {/* Add to Cart for all screens */}
      <button
        className={`bg-danger rounded-pill d-flex px-3 py-2 border-0`}
        style={isMobile ? { marginLeft: '280px' } : { marginRight: '150px' }}
        onClick={handleCartClick} 
      >
        <img src="/cart.svg" alt="Cart" style={{ width: '24px', height: '30px' }} />
        <p className="text-white ms-2 mb-0">4</p>
      </button>
    </div>
  );
}
