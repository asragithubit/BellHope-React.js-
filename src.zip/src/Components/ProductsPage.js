import React from 'react'
import Navbar from './Navbar'
import Header from './Header'
import ProductsPageCategoriesSection from './ProductsPageCategoriesSection'
import FruitsandVegetables from './Fruits and Vegetables'
import Footer from './Footer'
import Packages from './Packages'

export default function ProductsPage() {
  const packageItems = [
    {
      imgSrc: "Vegetables.png",
      altText: "Vegetables",
      price: "$9.65",
      originalPrice: "$11.25",
      description: "Tomato, Carrot, Green Lime, Onion, Potato, Red Chili",
    },
    {
      imgSrc: "Vegetables.png",
      altText: "Vegetables",
      price: "$9.65",
      originalPrice: "$11.25",
      description: "Tomato, Carrot, Green Lime, Onion, Potato, Red Chili",
    }
  ];
  return (
    <div>
      <Navbar/>
      <Header imgLink="/ProductsHeaderIcon.png"/>
      <ProductsPageCategoriesSection/>
      <FruitsandVegetables title='Fruits and Vegetables'/>
      <Packages items={packageItems}/>
      <Footer/>
    </div>
  )
}
