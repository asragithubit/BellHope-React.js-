import React from 'react';
import { useMediaQuery } from 'react-responsive';

const Footer = () => {
    const isMobile = useMediaQuery({ query: '(max-width: 576px)' });
  return (
    <footer className="bg-light text-dark pt-5 pb-4">
      <div className="container text-center text-md-start">
        <div className="row text-center text-md-start">
          {/* Logo Section */}
          <div className="col-md-4 mx-auto mt-3">
            <img src="/logo.png" alt="Logo" className="img-fluid mx-md-1 mx-1 my-2" style={{ width: "120px", height: "80px" }} />
            <p className='text-gray'>
                Our food delivery service for short-term rentals helps stock your fridge with fresh, locally sourced groceries before you arrive. Browse our selection online and enjoy the convenience of having a full fridge waiting for you when you arrive, so you can focus on enjoying your trip.
                </p>
            </div>

          {/* Links Section */}
          <div className="col-md-2 col-4 mx-auto mt-5">
            <h6 className="text-uppercase mb-4 font-weight-bold">Links</h6>
            <p><a href="#!" className="text-dark">Become a Partner</a></p>
            <p><a href="#!" className="text-dark">Rentals</a></p>
            <p><a href="#!" className="text-dark">My Cart</a></p>
          </div>

          {/* Help Section */}
          <div className="col-md-3 col-4 mx-auto mt-5">
            <h6 className="text-uppercase mb-4 font-weight-bold">Help</h6>
            <p><a href="#!" className="text-dark">Contact Us</a></p>
            <p><a href="#!" className="text-dark">Privacy Policy</a></p>
            <p><a href="#!" className="text-dark">Payments</a></p>
          </div>
        </div>
        <hr className="mb-4" />

        {/* Payment Section */}
        <div className="row">
          {/* Left section: Copyright text */}
          <div className="col-md-3 ms-md-5">
            <p className="text-md-start text-center">
              © 2023 BellHopt. All rights reserved.
            </p>
          </div>

          {/* Center section: Payment buttons (Hidden on mobile) */}
          <div className="col-md-4 d-flex justify-content-center justify-content-md-end mb-3 mb-md-0">
            <button className="btn btn-sm mx-1" style={isMobile ? { display: 'none' } : {}}>
              <img src="/Master card.svg" alt="MasterCard" />
            </button>
            <button className="btn btn-sm mx-1" style={isMobile ? { display: 'none' } : {}}>
              <img src="/Pay.png" alt="Pay" />
            </button>
            <button className="btn btn-sm mx-1" style={isMobile ? { display: 'none' } : {}}>
              <img src="/Amex.png" alt="Amex" />
            </button>
          </div>

          {/* Right section: Social media buttons */}
          <div className="col-md-4 d-flex flex-md-row justify-content-center">
            <button className="btn btn-sm mx-1 mb-2 mb-md-0">
              <img src="/Facebook.svg" alt="Facebook" />
            </button>
            <button className="btn btn-sm mx-1 mb-2 mb-md-0">
              <img src="/LinkedIn.svg" alt="LinkedIn" />
            </button>
            <button className="btn btn-sm mx-1 mb-2 mb-md-0">
              <img src="/Instagram.svg" alt="Instagram" />
            </button>
            <button className="btn btn-sm mx-1 mb-2 mb-md-0">
              <img src="/Twitter.svg" alt="Twitter" />
            </button>
          </div>
        </div>
        </div>
    </footer>
  );
};

export default Footer;
