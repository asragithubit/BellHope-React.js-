import React from 'react';
import { useMediaQuery } from 'react-responsive';

export default function Body() {
    const isMobile = useMediaQuery({ query: '(max-width: 576px)' });
    return (
    <>
    <div className="container mt-3 my-5">
        <div className="d-flex justify-content-between align-items-center mb-3">
            <h2><b>Fruits and Vegetables</b></h2>
            <div>
                <button className="btn btn-sm mx-1" style={isMobile ? { display: 'none' } : {}}>
                    <img src="/LeftArrow.png" alt="Left Arrow Button" />
                </button>
                <button className="btn btn-sm" style={isMobile ? { display: 'none' } : {}}>
                    <img src="/RightArrow.png" alt="Right Arrow Button" />
                </button>
                <a href="/" className="text-danger">See all</a>
            </div>
        </div>
        <div className="row row-cols-2 row-cols-lg-4 g-4 px-2">
            <div className="col">
                <div className="card border-0 h-100">
                    <img src="Strawberry.png" className="card-img-top" alt="Strawberry" />
                </div>
            </div>
            <div className="col">
                <div className="card border-0 h-100">
                    <img src="Apple Green.png" className="card-img-top" alt="Green Apple" />
                </div>
            </div>

            <div className="col">
                <div className="card border-0 h-100">
                    <img src="Orange.png" className="card-img-top" alt="Orange" />
                </div>
            </div>

            <div className="col">
                <div className="card border-0 h-100">
                    <img src="Green Lemon.png" className="card-img-top" alt="Green Lemon" />
                </div>
            </div>
        </div>
        <div className="row row-cols-2 row-cols-lg-4 g-4 px-2">
            <div className="col">
                <div className="card border-0 h-100">
                    <img src="Red Onion.png" className="card-img-top" alt="Red Onion" />
                </div>
            </div>
            <div className="col">
                <div className="card border-0 h-100">
                    <img src="Tomato.png" className="card-img-top" alt="Tomato" />
                </div>
            </div>

            <div className="col">
                <div className="card border-0 h-100">
                    <img src="Pomegrante.png" className="card-img-top" alt="Pomegrante" />
                </div>
            </div>

            <div className="col">
                <div className="card border-0 h-100">
                    <img src="Potato.png" className="card-img-top" alt="Potato" />
                </div>
            </div>
        </div>
    </div>
    <div className="container mt-3 my-5 mx-5">
        <div className="d-flex justify-content-between align-items-center mb-3 ms-md-5 ps-md-5">
            <h2 className='ms-md-5'><b>Packages</b></h2>
            <div>
                <button className="btn btn-sm mx-1" style={isMobile ? { display: 'none' } : {}}>
                    <img src="/LeftArrow.png" alt="Left Arrow Button" />
                </button>
                <button className="btn btn-sm" style={isMobile ? { display: 'none' } : {}}>
                    <img src="/RightArrow.png" alt="Right Arrow Button" />
                </button>
                <a href="/" className="text-danger ms-2">See all</a>
            </div>
        </div>
        <div className="row row-cols-2 row-cols-lg-4 px-2 justify-content-center">
            <div className="col mt-2">
                <div className="card h-100 d-flex flex-column">
                    <div className="ratio ratio-1x1">
                        <img src="SpriteFanta.png" className="card-img-top" alt="Coke, Sprite, Fanta"/>
                    </div>
                    <div className="card-body mt-auto">
                        <p className="card-text"><b>$9.65</b> <del>$11.25</del></p>
                        <p className="card-text mb-4">"Coca-Cola, Sprite, Fanta (12-pack Variety)
                        </p>
                        <button className="btn btn-dark btn-sm rounded-pill mt-1">Add to cart</button>
                        <a href="/" className="text-muted d-block d-sm-inline ms-sm-5 mt-2 mt-sm-0">Edit Items</a>
                    </div>
                </div>
            </div>

            <div className="col mt-2">
                <div className="card h-100 d-flex flex-column">
                    <div className="ratio ratio-1x1">
                        <img src="TomatoLime.png" className="card-img-top" alt="Whiskey Package"/>
                    </div>
                    <div className="card-body mt-auto">
                        <p className="card-text"><b>$129.65</b> <del>$131.25</del></p>
                        <p className="card-text">Lorem ipsum dollar sign is the placeholder text.</p>
                        <button className="btn btn-dark btn-sm rounded-pill mt-md-1 mt-3">Add to cart</button>
                        <a href="/" className="text-muted d-block d-sm-inline ms-sm-5 mt-2 mt-sm-0">Edit Items</a>
                    </div>
                </div>
            </div>

            <div className="col mt-2">
                <div className="card h-100 d-flex flex-column">
                    <div className="ratio ratio-1x1">
                        <img src="Dove.png" className="card-img-top" alt="Dove Package"/>
                    </div>
                    <div className="card-body mt-auto">
                        <p className="card-text"><b>$9.65</b> <del>$11.25</del></p>
                        <p className="card-text">Tomato, Carrot, Green Lime, Onion, Potato, Red Chili</p>
                        <button className="btn btn-dark btn-sm rounded-pill">Add to cart</button>
                    <a href="/" className="text-muted d-block d-sm-inline ms-sm-5 mt-2 mt-sm-0">Edit Items</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </>
  );
} 
