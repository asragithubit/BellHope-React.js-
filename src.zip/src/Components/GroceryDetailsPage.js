import React from 'react';
import Navbar from './Navbar';
import FruitsandVegetables from './Fruits and Vegetables';
import Footer from './Footer';
import { useNavigate } from 'react-router-dom';

export default function GroceryDetailsPage() {
  const navigate=useNavigate();
  const handleClick = () => {
    navigate('/checkout'); 
  };
  return (
    <>
      {/* Navbar */}
      <Navbar />
      <hr className="text-gray w-100" />
      {/* Grocery/Product Detail Section */}
      <div className="container my-5 px-md-5">
        <div className="row align-items-center">
          {/* Back Arrow */}
          <div className="col d-flex">
            <a href="/">
              <img
                src="BackIcon.png"
                alt="Back"
                className='mt-5 ms-md-5 ms-3'
                style={{ width: '18px', height: '18px' }}
              />
            </a>
            <p className="mx-2 mt-5">Grocery/product detail</p>
          </div>
        </div>

        <div className="row">
          {/* Left Section: Image and Related Items */}
          <div className="col-md-5 col-10 mx-md-5 mx-4 px-4 py-2 mb-4" style={{ border: '1px solid gray' }}>
            <img
              src="OrangeGroceryPage.png"
              alt="Orange - 1 Dozen"
              className="img-fluid rounded"
              style={{ maxHeight: '400px', objectFit: 'cover' }}
            />

            {/* Related Items below the image */}
            <div className="mt-4">
              <div className="d-flex justify-content-center">
                <img
                  src="OrangeItem1.png"
                  alt="Related item 1"
                  className="img-thumbnail mx-2 border-0"
                  style={{ width: '60px', height: '60px' }}
                />
                <img
                  src="OrangeItem2.png"
                  alt="Related item 2"
                  className="img-thumbnail mx-2 border-0"
                  style={{ width: '60px', height: '60px' }}
                />
                <img
                  src="OrangeItem3.png"
                  alt="Related item 3"
                  className="img-thumbnail mx-2 border-0"
                  style={{ width: '60px', height: '60px' }}
                />
                <img
                  src="OrangeItem2.png"
                  alt="Related item 3"
                  className="img-thumbnail mx-2 border-0"
                  style={{ width: '60px', height: '60px' }}
                />
              </div>
            </div>
          </div>

          {/* Right Section: Product Details */}
          <div className="col-md-3 col-10 mx-4 px-4 py-4" style={{ border: '1px solid gray' }}>
            <h4><b>ORANGE - 1 DOZEN</b></h4>
            <p>SKU: VIP Orange/Dz</p>
            <p>Vendor: Lorem Ipsum</p>
            <p className="text-success">
              <img src="HighStock.png" alt="Stock Icon" className="me-2" />
              High Stock
            </p>

            <h4 className="mt-4">
              <b>Price: <span className="text-black">$8.50</span></b>
            </h4>

            <button className="btn btn-danger btn-lg mt-3 rounded-pill" onClick={handleClick}>Add to Cart</button>
            <hr className="text-gray mx-3 my-5" />
            <p className="mt-3">
              <a href="/" className="text-primary mx-2">
                <img src="GuaranteeIcon.png" alt="Guarantee" className="mx-1" />
                100% satisfaction guaranteed
              </a>
            </p>
          </div>
        </div>
      </div>

      {/* Fruits and Vegetables section */}
      <FruitsandVegetables title="Related Items" />

      {/* Footer */}
      <Footer />
    </>
  );
}
