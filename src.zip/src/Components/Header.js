import React from 'react';
import { useMediaQuery } from 'react-responsive';

export default function Header(props) {

    const isMobile = useMediaQuery({ query: '(max-width: 576px)' });
    const isTablet = useMediaQuery({ query: '(min-width: 576px) and (max-width: 768px)' });

    const imgStyle = {
        width: isMobile || isTablet ? '200px' : '550px',
        height: isMobile || isTablet ? '190px' : '250px',
    };

    return (
        <div className="container-fluid bg-danger text-white d-flex py-lg-5 py-md-5 py-1 w-100" style={{ height: '300px' }}>
            <div className="row w-100 ms-xl-5 ms-lg-5 ms-md-5 ms-1">
                <div className="col-md-4 col-5 text-lg-start pt-md-5 py-2">
                    <h1 className="fw-bold mt-md-3 mt-3">Be The Fastest In Delivering Your Foods</h1>
                    <p className="lead">We’re always available to serve you!</p>
                </div>

                <div className="col d-flex justify-content-end pe-md-3 py-5 py-md-1">
                    <img
                        src={props.imgLink}
                        alt="Scooter"
                        className="hero-img"
                        style={imgStyle} />
                </div>
            </div>
        </div>
    );
}