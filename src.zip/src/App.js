import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './HomePage';
import MyCart from './Components/MyCart';
import Checkout from './Components/Checkout';
import ThankYouPage from './Components/ThankYouPage';
import GroceryDetailsPage from './Components/GroceryDetailsPage';
import ProductsPage from './Components/ProductsPage';
function App() {
  return (
    <Router>
      <Routes>
        {/* Define a route for HomePage */}
        <Route path="/" element={<HomePage />} />

        {/* Define other routes */}
        <Route path="/mycart" element={<MyCart />} />
        <Route path="/checkout" element={<Checkout />} />
        <Route path="/thankYou" element={<ThankYouPage />} />
        <Route path="/grocery" element={<GroceryDetailsPage />} />
        <Route path="/products" element={<ProductsPage />} />

      </Routes>
    </Router>
  );
}

export default App;
