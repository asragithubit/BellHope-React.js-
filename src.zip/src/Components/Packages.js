import React from 'react';
import { useMediaQuery } from 'react-responsive';
import { useNavigate } from 'react-router-dom';

export default function Packages({ items }) {
  const isMobile = useMediaQuery({ query: '(max-width: 576px)' });
  const handleClick = () => {
    navigate('/grocery'); 
  };

  const navigate = useNavigate(); // Hook for navigation

  return (
    <div className="container mt-3 my-5 mx-5">
        <div className="d-flex justify-content-between align-items-center mb-3 ms-md-5 ps-md-5">
            <h2 className='ms-md-5'><b>Packages</b></h2>
            <div>
                <button className="btn btn-sm mx-1" style={isMobile ? { display: 'none' } : {}}>
                    <img src="/LeftArrow.png" alt="Left Arrow Button" />
                </button>
                <button className="btn btn-sm" style={isMobile ? { display: 'none' } : {}}>
                    <img src="/RightArrow.png" alt="Right Arrow Button" />
                </button>
                <a href="/" className="text-danger ms-2">See all</a>
            </div>
        </div>

        <div className="row row-cols-2 row-cols-lg-4 px-2 justify-content-center">
            {items.map((item, index) => (
                <div className="col mt-2" key={index}>
                    <div className="card h-100 d-flex flex-column">
                        <div className="ratio ratio-1x1">
                            <img src={item.imgSrc} className="card-img-top" alt={item.altText} />
                        </div>
                        <div className="card-body mt-auto">
                            <p className="card-text"><b>{item.price}</b> <del>{item.originalPrice}</del></p>
                            <p className="card-text mb-4">{item.description}</p>
                            <button className="btn btn-dark btn-sm rounded-pill mt-1" onClick={handleClick}>Add to cart</button>
                            <a href="/" className="text-muted d-block d-sm-inline ms-sm-5 mt-2 mt-sm-0">Edit Items</a>
                        </div>
                    </div>
                </div>
            ))}
        </div>
    </div>
  );
}
