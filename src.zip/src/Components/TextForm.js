import React, { useState } from 'react'

export default function TextForm() {
    const [text,setText]=useState("");

    const convertToUpperCase=()=>{
        let newText=text.toUpperCase();
        setText(newText);
    };

    const convertToLowerCase=()=>{
        let newText=text.toLowerCase();
        setText(newText);
    };

    const clearText=()=>{
        setText("");
    };

    const handleEvent=(event)=>{
        setText(event.target.value);
    }
  return (
    <>
            <h2 className="mx-5">Enter Your Text Here....</h2>
            <div className="input-group">
            <textarea  className="mx-5 my-2 form-control" rows="8" value={text} onChange={handleEvent} aria-label="With textarea"></textarea>
            </div>
            <button disabled={text.length===0} className="btn btn-success ms-5" onClick={convertToUpperCase}>Convert to Uppercase</button>
            <button disabled={text.length===0} className="btn btn-primary mx-1" onClick={convertToLowerCase}>Convert to LowerCase</button>
            <button disabled={text.length===0} className="btn btn-danger mx-1" onClick={clearText}>Clear Text</button>

            <h2 className="ms-5 mt-3">Text Summary</h2>
            <p className="ms-5">{text.split(' ').length} words and {text.length} characters.</p>
            <h2 className="ms-5">Preview</h2>
            <p className="ms-5">{text}</p>

    </>
        
  )
}
