import React from 'react';
import { useMediaQuery } from 'react-responsive'; // Import useMediaQuery from react-responsive
import { Container, Row, Col } from 'react-bootstrap';

export default function ProductsPageCategoriesSection() {
    const isMobile = useMediaQuery({ query: "(max-width: 576px)" });

    return (
        <Container fluid className="bg-light">
            <Row className="d-flex justify-content-between align-items-center">
                {/* Left arrow - only visible on larger screens */}
                <Col xs="1" className="d-none d-md-flex align-items-center my-5">
                    <button className="btn btn-light">
                        <img src='/LeftArrow.png' alt='Left Arrow Button' />
                    </button>
                </Col>

                {/* Scrollable row for categories */}
                <Col xs={10} className="overflow-auto">
                    <div className="d-flex justify-content-between" style={{ whiteSpace: 'nowrap' }}>
                        {[
                            { icon: 'fas fa-fire', label: 'Sale', image: 'Sale.png', color: 'text-black' },
                            { icon: 'fas fa-star', label: 'Trending', image: 'Trending.png', color: 'text-black' },
                            { icon: 'fas fa-box', label: 'Packages', image: 'Packages.png', color: 'text-black' },
                            { icon: 'fas fa-shopping-basket', label: 'Groceries', image: 'Groceries.png', color: 'text-black' },
                            { icon: 'fas fa-wine-bottle', label: 'Alcohol', image: 'Alcohol.png', color: 'text-black' },
                            { icon: 'fas fa-ice-cream', label: 'Desserts', image: 'Desserts.png', color: 'text-black' },
                            { icon: 'fas fa-coffee', label: 'Beverages', image: 'Beverages.png', color: 'text-black' },
                            { icon: 'fas fa-paw', label: 'Pet Supplies', image: 'pets.png', color: 'text-black' },
                            { icon: 'fas fa-home', label: 'Rentals', image: 'Rentals.png', color: 'text-black' }
                        ].map((item, index) => (
                            <button key={index} className={`btn d-inline-block mx-2 ${item.color}`} style={{ textAlign: 'center' }}>
                                <div className='my-1 bg-white rounded-circle d-flex align-items-center justify-content-center'
                                    style={{ width: '60px', height: '60px' }}>
                                    <img src={item.image} alt={item.label} style={{ width: '40px', height: '40px' }} />
                                </div>
                                <p>{item.label}</p>
                            </button>
                        ))}
                    </div>
                </Col>

                {/* Right arrow - only visible on larger screens */}
                <Col xs="1" className="d-none d-md-flex align-items-center">
                    <button className="btn btn-light">
                        <img src="RightArrow.png" alt="Right Arrow Button" />
                    </button>
                </Col>
            </Row>
        </Container>
    )
}
